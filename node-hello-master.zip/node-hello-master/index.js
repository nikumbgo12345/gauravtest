const createLibp2p = require('libp2p')
const mdns = require('@libp2p/mdns')
const tcp = require('@libp2p/tcp')
const mplex = require('@libp2p/mplex')
const noise = require('@chainsafe/libp2p-noise')


const http = require('http');
const port = process.env.PORT || 3000;

const server = http.createServer(async (req, res) => {
  res.statusCode = 200;
  const msg = 'Hello Node!\n'

  const createNode = () => {
    return createLibp2p({
      addresses: {
        listen: ['/ip4/0.0.0.0/tcp/0']
      },
      transports: [
        tcp()
      ],
      streamMuxers: [
        mplex()
      ],
      connectionEncryption: [
        noise()
      ],
      peerDiscovery: [
        mdns({
          interval: 20e3
        })
      ]
    })
  }


  const [node1, node2] = await Promise.all([
    createNode(),
    createNode()
  ])

  node1.addEventListener('peer:discovery', (evt) => console.log('Discovered:', evt.detail.id.toString()))
  node2.addEventListener('peer:discovery', (evt) => console.log('Discovered:', evt.detail.id.toString()))


  res.end(msg);
});

server.listen(port, () => {
  console.log(`Server running on http://localhost:${port}/`);
});
